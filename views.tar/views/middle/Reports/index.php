<div class="page-title">
    <div class="container clearfix">
    	<h3 class="text">
           <a href="<?php echo site_url('reports/index/pendancy_leads_reports')?>">1.Pendancy Leads Report</a>
        </h3>
    </div>
    <hr>
    <div class="container clearfix">
    	<h3 class="text">
           <a href="<?php echo site_url('reports/index/leads_type_reports')?>">2.Leads Type Report</a>
        </h3>
	</div>
	<hr>
	<div class="container clearfix">
		<h3 class="text">
           <a href="<?php echo site_url('reports/index/leads_generated')?>">3.Leads Generated Report</a>
        </h3>
	</div>
	<hr>
	<div class="container clearfix">
		<h3 class="text">
           <a href="<?php echo site_url('reports/index/leads_assigned')?>">4.Leads Assigned Report</a>
        </h3>
	</div>
	<hr>
	<div class="container clearfix">
		<h3 class="text">
           <a href="<?php echo site_url('reports/index/leads_generated_vs_converted')?>">5.Leads Generated Vs Converted Report</a>
        </h3>
	</div>
	<hr>
  <div class="container clearfix">
    <h3 class="text">
           <a href="<?php echo site_url('reports/index/leads_classification')?>">6.Leads Classification Report</a>
        </h3>
  </div>
  <hr>
  <div class="container clearfix">
    <h3 class="text">
           <a href="<?php echo site_url('reports/index/usage')?>">7.Usage Report</a>
        </h3>
  </div>
  <hr>
</div>