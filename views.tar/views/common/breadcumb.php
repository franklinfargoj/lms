<!-- BEGIN PAGE BREADCRUMB -->
<div class="breadcrumbs">
    <div class="container clearfix">
        <?php echo $breadcrumb ;?>        
    </div>
</div>
<!-- END PAGE BREADCRUMB -->