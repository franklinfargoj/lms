<?php

/**
 *
 * This is App Model
 *
 * @author    Gourav Thatoi
 * @subpackage    Model
 */
class App extends CI_Model
{
    public function __construct()
    {
        parent::__construct();

    }
    
}